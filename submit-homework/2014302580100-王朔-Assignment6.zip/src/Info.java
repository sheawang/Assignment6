import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;

public class Info extends JFrame {

	public Connection conn;
	public Statement sql;
	private JPanel contentPane;
	static double [] value=new double[]{200,150,300,500,400,100,50,120,240,110,60,87};
//	static ArrayList<Integer> number=new ArrayList<Integer>();//�洢ÿ�ֶ��������
//	static Integer [] integer=nums.toArray(new Integer[nums.size()]);
	static ArrayList<String> texts=new ArrayList<String>();
	static int numbers;
	static int nums=1;//������¼���빺�ﳵ��һ���м��ֳ���

	

	/**
	 * Create the frame.         
	 */
	public Info() {
		numbers=0;
		Database d=new Database();
		ArrayList<String> names=new ArrayList<String>();
		ArrayList<String> eats=new ArrayList<String>();
		ArrayList<String> drinks=new ArrayList<String>();
		ArrayList<String> lives=new ArrayList<String>();
		ArrayList<String> hobbies=new ArrayList<String>();
		ArrayList<String> content=new ArrayList<String>();
		conn=d.getConnection();
		try {
			sql=conn.createStatement();
			ResultSet res=sql.executeQuery("select * from pet");
			while(res.next())
			{
				String name=res.getString("name");
				String eat=res.getString("eat");
				String drink=res.getString("drink");
				String live=res.getString("live");
				String hobby=res.getString("hobby");
				
				names.add(name);
				eats.add(eat);
				drinks.add(drink);
				lives.add(live);
				hobbies.add(hobby);
				content.add("name:"+name+"\neat:"+eat+"\ndrink:"+drink+"\nlive:"+live+"\nhobby:"+hobby);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		CharSequence [] cs=content.toArray(new CharSequence[content.size()]);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(109, 109, 237, 206);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setEnabled(false);
		int num=User.getNum();
		textArea.setText(cs[num].toString()+"\ncost:"+value[num]);
		textArea.setBounds(10, 0, 217, 159);
		panel.add(textArea);
		
		//���빺�ﳵ
		JButton btnNewButton = new JButton("\u52A0\u5165\u8D2D\u7269\u8F66");
		btnNewButton.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				if(numbers<1)
				{
					texts.add(textArea.getText());
					nums++;
//					number.add(numbers);
					numbers++;
				}else
				{
//					number.add(numbers);
					numbers++;
				}
//				System.out.println(numbers);
				
				
			}
		});

//		Integer [] integer=number.toArray(new Integer[number.size()]);
//		n=integer[integer.length-1];

		btnNewButton.setBounds(10, 169, 93, 23);
		panel.add(btnNewButton);
		//����
		JButton btnNewButton_1 = new JButton("\u8FD4\u56DE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				User user=new User();
				user.setVisible(true);
				
			}
		});
		btnNewButton_1.setBounds(134, 169, 93, 23);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("\u5546\u54C1\u8BE6\u60C5");
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 18));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(109, 32, 237, 48);
		contentPane.add(lblNewLabel);
	}
}
