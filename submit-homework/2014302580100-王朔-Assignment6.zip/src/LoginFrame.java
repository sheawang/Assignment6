import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class LoginFrame extends JFrame {

	public Connection conn;
	public Statement sql;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;
	private ResultSet res;
	protected ResultSet res1;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		Database d=new Database();
		conn=d.getConnection();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		panel.setBounds(108, 122, 228, 153);
		contentPane.add(panel);
		
		JLabel lblLogin = new JLabel("Login");
		lblLogin.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogin.setBounds(81, 5, 69, 15);
		panel.add(lblLogin);
		
		textField = new JTextField();
		textField.setColumns(10);
		textField.setBounds(81, 34, 121, 25);
		panel.add(textField);
		
		JLabel label_1 = new JLabel("password:");
		label_1.setBounds(10, 82, 69, 15);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("username:");
		label_2.setBounds(10, 39, 69, 15);
		panel.add(label_2);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(81, 79, 121, 25);
		panel.add(passwordField);
		
		JButton btnConfirm = new JButton("Confirm");
		btnConfirm.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=textField.getText().trim();
				String password1=passwordField.getText().trim();
				conn=d.getConnection();
				try {
					sql=conn.createStatement();
					res1=sql.executeQuery("select * from pet_2014302580100_users");
					while(res1.next())
					{
						if(name.equals(res1.getString("name")))
						{
							res=sql.executeQuery("select * from pet_2014302580100_users where name ="+"'"+name+"'");
							while(res.next())
							{
								if(password1.equals(res.getString("password")))
								{
									dispose();
									User user=new User();
									getContentPane().removeAll();
									panel.setVisible(false);
									user.setVisible(true);
								}else{
									JOptionPane.showMessageDialog(null,"��������������������룡");
									passwordField.setText("");
								}
							}
						}else
						{
							JOptionPane.showMessageDialog(null, "�û��������ڣ������������û�����������ע��");
							textField.setText("");
							passwordField.setText("");
						}
					}
					
				} catch (SQLException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
				
				
			}
		});
		btnConfirm.setBounds(125, 120, 93, 23);
		panel.add(btnConfirm);
		
		JButton btnNewButton = new JButton("SignUp");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				SignUpFrame signup=new SignUpFrame();
				signup.setVisible(true);
			}
		});
		btnNewButton.setBounds(10, 120, 93, 23);
		panel.add(btnNewButton);
		
		JLabel label = new JLabel("\u6B22\u8FCE\u767B\u5F55");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(108, 50, 228, 39);
		contentPane.add(label);
	}
}
