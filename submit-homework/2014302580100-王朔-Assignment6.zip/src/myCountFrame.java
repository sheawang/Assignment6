import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class myCountFrame extends JFrame {

	
	private JPanel contentPane;
	private double count=1000;//��ʼ���Ϊ1000
	private JTextField textField;
	ArrayList<Integer> number=myShoppingFrame.position;
	private double sum=0;



	/**
	 * Create the frame.
	 */
	public myCountFrame() {
		//��left����ֵ
		Integer [] integer=number.toArray(new Integer[number.size()]);
		for(int i=0;i<integer.length;i++)
		{
			sum+=Info.value[integer[i]]*Info.numbers;
		}
		setCount(getCount()-sum);
		if(getCount()<0)
		{
			JOptionPane.showMessageDialog(null, "�������㣡���ֵ��");
		}
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(37, 91, 339, 194);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("\u6211\u7684\u8D26\u6237\u4F59\u989D\uFF1A");
		lblNewLabel.setBounds(78, 54, 91, 29);
		panel.add(lblNewLabel);
		
		textField = new JTextField();
		textField.setBounds(179, 58, 66, 21);
		if(getCount()<0)
		{
			JOptionPane.showMessageDialog(null, "�������㣡���ֵ��");
		}else
		{
			textField.setText(String.valueOf(getCount()));
		}
		 
		panel.add(textField);
		textField.setColumns(10);
		//�����ҵĹ��ﳵ����
		JButton button = new JButton("\u8FD4\u56DE\u6211\u7684\u8D2D\u7269\u8F66");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				myShoppingFrame shopping=new myShoppingFrame();
				Info.nums=0;
				shopping.setVisible(true);
			}
		});
		button.setBounds(39, 134, 117, 23);
		panel.add(button);
		
		//�����û�����
		JButton button_1 = new JButton("\u8FD4\u56DE\u7528\u6237\u754C\u9762");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				User user=new User();
				user.setVisible(true);
			}
		});
		button_1.setBounds(179, 135, 117, 21);
		panel.add(button_1);
		
		JLabel label = new JLabel("\u6211\u7684\u8D26\u6237");
		label.setFont(new Font("����", Font.PLAIN, 16));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(129, 45, 172, 27);
		contentPane.add(label);
	}



	public double getCount() {
		return count;
	}



	public void setCount(double count) {
		this.count = count;
	}
}
