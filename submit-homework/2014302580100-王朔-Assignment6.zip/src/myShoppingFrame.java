import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.JCheckBox;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

public class myShoppingFrame extends JFrame {

	private JPanel contentPane;
	ArrayList<String> content=Info.texts;
	public String[] s=new String[12];//�洢ѡ��ѡ��ѡ�е�����
	static int k=Info.nums;//������¼Ҫ��ʾ�Ķ����м���
//	public static int[] position=new int[12];
	static ArrayList<Integer> position=new ArrayList<Integer>();//�洢�����λ�� �Է���õ��۸�


	/**
	 * Create the frame.
	 */
	public myShoppingFrame() {
		//��ArrayList<String>ת���ַ����Թ�д��textarea��
		CharSequence[] ch=content.toArray(new CharSequence[content.size()]);
		String [] string=new String[12];
		int [] num=new int[12];
		//��ʼ��
		for(int i=0;i<12;i++)
		{
			s[i]="";
			string[i]="";
			num[i]=0;
		}
		//������빺�ﳵ������С���ı�������� �ͰѶ���ı����Ϳ�
		for(int j=0;j<k-1;j++)
		{
//			num[j]=integer[j];
			string[j]=ch[j].toString()+"\nnumbers:"+Info.numbers;
			System.out.println(string[j]);
		}
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 434, 412);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel label = new JLabel("\u6211\u7684\u8D2D\u7269\u8F66");
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setBounds(134, 0, 140, 34);
		panel.add(label);
		
		JCheckBox checkBox = new JCheckBox("\u9009\u62E9");
		checkBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if(string[0]!="")
				{
					position.add(0);
				}
			}
		});
		checkBox.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox.setBounds(10, 80, 103, 23);
		panel.add(checkBox);
		
		JCheckBox checkBox_1 = new JCheckBox("\u9009\u62E9");
		checkBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[1]!="")
				{
					position.add(1);
				}
			}
		});
		checkBox_1.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_1.setBounds(163, 80, 103, 23);
		panel.add(checkBox_1);
		
		JCheckBox checkBox_2 = new JCheckBox("\u9009\u62E9");
		checkBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[2]!="")
				{
					position.add(2);
				}
			}
		});
		checkBox_2.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_2.setBounds(321, 80, 103, 23);
		panel.add(checkBox_2);
		
		JCheckBox checkBox_3 = new JCheckBox("\u9009\u62E9");
		checkBox_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[3]!="")
				{
					position.add(3);
				}
			}
		});
		checkBox_3.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_3.setBounds(10, 165, 103, 23);
		panel.add(checkBox_3);
		
		JCheckBox checkBox_4 = new JCheckBox("\u9009\u62E9");
		checkBox_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[4]!="")
				{
					position.add(4);
				}
			}
		});
		checkBox_4.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_4.setBounds(163, 165, 103, 23);
		panel.add(checkBox_4);
		
		JCheckBox checkBox_5 = new JCheckBox("\u9009\u62E9");
		checkBox_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[5]!="")
				{
					position.add(5);
				}
			}
		});
		checkBox_5.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_5.setBounds(321, 165, 103, 23);
		panel.add(checkBox_5);
		
		JCheckBox checkBox_6 = new JCheckBox("\u9009\u62E9");
		checkBox_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[6]!="")
				{
					position.add(6);
				}
			}
		});
		checkBox_6.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_6.setBounds(10, 251, 103, 23);
		panel.add(checkBox_6);
		
		JCheckBox checkBox_7 = new JCheckBox("\u9009\u62E9");
		checkBox_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[7]!="")
				{
					position.add(7);
				}
			}
		});
		checkBox_7.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_7.setBounds(163, 248, 103, 23);
		panel.add(checkBox_7);
		
		JCheckBox checkBox_8 = new JCheckBox("\u9009\u62E9");
		checkBox_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[8]!="")
				{
					position.add(8);
				}
			}
		});
		checkBox_8.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_8.setBounds(321, 251, 103, 23);
		panel.add(checkBox_8);
		
		JCheckBox checkBox_9 = new JCheckBox("\u9009\u62E9");
		checkBox_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[9]!="")
				{
					position.add(9);
				}
			}
		});
		checkBox_9.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_9.setBounds(10, 333, 103, 23);
		panel.add(checkBox_9);
		
		JCheckBox checkBox_10 = new JCheckBox("\u9009\u62E9");
		checkBox_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[10]!="")
				{
					position.add(10);
				}
			}
		});
		checkBox_10.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_10.setBounds(163, 333, 103, 23);
		panel.add(checkBox_10);
		
		JCheckBox checkBox_11 = new JCheckBox("\u9009\u62E9");
		checkBox_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(string[11]!="")
				{
					position.add(11);
				}
			}
		});
		checkBox_11.setHorizontalAlignment(SwingConstants.CENTER);
		checkBox_11.setBounds(321, 333, 103, 23);
		panel.add(checkBox_11);
		//���㰴ť
		JButton button = new JButton("\u7ED3\u7B97");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				myCountFrame mycount=new myCountFrame();
				mycount.setVisible(true);
			}
		});
		button.setBounds(63, 379, 93, 23);
		panel.add(button);
		//ɾ����ť
		JButton button_1 = new JButton("\u6E05\u7A7A");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for(int i=0;i<k;i++)
				{
					string[i]="";
				}
				dispose();
				myShoppingFrame shopping=new myShoppingFrame();
				k=0;
				shopping.setVisible(true);
				
			}
		});
		button_1.setBounds(180, 379, 93, 23);
		panel.add(button_1);
		
		//�����û�����
		JButton button_2 = new JButton("\u8FD4\u56DE");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				User user=new User();
				user.setVisible(true);
			}
		});
		button_2.setBounds(294, 379, 93, 23);
		panel.add(button_2);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 32, 110, 50);
		panel.add(scrollPane);
		
		JTextArea textArea = new JTextArea();
		textArea.setEnabled(false);
		textArea.setEditable(false);
		textArea.setText(string[0]);
		scrollPane.setViewportView(textArea);
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(163, 32, 110, 50);
		panel.add(scrollPane_1);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setEnabled(false);
		textArea_1.setEditable(false);
		textArea_1.setText(string[1]);
		scrollPane_1.setViewportView(textArea_1);
		
		JScrollPane scrollPane_2 = new JScrollPane();
		scrollPane_2.setBounds(314, 32, 110, 50);
		panel.add(scrollPane_2);
		
		JTextArea textArea_2 = new JTextArea();
		textArea_2.setEnabled(false);
		textArea_2.setEditable(false);
		textArea_2.setText(string[2]);
		scrollPane_2.setViewportView(textArea_2);
		
		JScrollPane scrollPane_3 = new JScrollPane();
		scrollPane_3.setBounds(10, 109, 110, 50);
		panel.add(scrollPane_3);
		
		JTextArea textArea_3 = new JTextArea();
		textArea_3.setEnabled(false);
		textArea_3.setEditable(false);
		textArea_3.setText(string[3]);
		scrollPane_3.setViewportView(textArea_3);
		
		JScrollPane scrollPane_4 = new JScrollPane();
		scrollPane_4.setBounds(163, 109, 110, 50);
		panel.add(scrollPane_4);
		
		JTextArea textArea_4 = new JTextArea();
		textArea_4.setEnabled(false);
		textArea_4.setEditable(false);
		textArea_4.setText(string[4]);
		scrollPane_4.setViewportView(textArea_4);
		
		JScrollPane scrollPane_5 = new JScrollPane();
		scrollPane_5.setBounds(314, 109, 110, 50);
		panel.add(scrollPane_5);
		
		JTextArea textArea_5 = new JTextArea();
		textArea_5.setEnabled(false);
		textArea_5.setEditable(false);
		textArea_5.setText(string[5]);
		scrollPane_5.setViewportView(textArea_5);
		
		JScrollPane scrollPane_6 = new JScrollPane();
		scrollPane_6.setBounds(10, 195, 110, 50);
		panel.add(scrollPane_6);
		
		JTextArea textArea_6 = new JTextArea();
		textArea_6.setEnabled(false);
		textArea_6.setEditable(false);
		textArea_6.setText(string[6]);
		scrollPane_6.setViewportView(textArea_6);
		
		JScrollPane scrollPane_7 = new JScrollPane();
		scrollPane_7.setBounds(163, 195, 110, 50);
		panel.add(scrollPane_7);
		
		JTextArea textArea_7 = new JTextArea();
		textArea_7.setEnabled(false);
		textArea_7.setEditable(false);
		textArea_7.setText(string[7]);
		scrollPane_7.setViewportView(textArea_7);
		
		JScrollPane scrollPane_8 = new JScrollPane();
		scrollPane_8.setBounds(314, 195, 110, 50);
		panel.add(scrollPane_8);
		
		JTextArea textArea_8 = new JTextArea();
		textArea_8.setEnabled(false);
		textArea_8.setEditable(false);
		textArea_8.setText(string[8]);
		scrollPane_8.setViewportView(textArea_8);
		
		JScrollPane scrollPane_9 = new JScrollPane();
		scrollPane_9.setBounds(10, 277, 110, 50);
		panel.add(scrollPane_9);
		
		JTextArea textArea_9 = new JTextArea();
		textArea_9.setEnabled(false);
		textArea_9.setEditable(false);
		textArea_9.setText(string[9]);
		scrollPane_9.setViewportView(textArea_9);
		
		JScrollPane scrollPane_10 = new JScrollPane();
		scrollPane_10.setBounds(163, 277, 110, 50);
		panel.add(scrollPane_10);
		
		JTextArea textArea_10 = new JTextArea();
		textArea_10.setEnabled(false);
		textArea_10.setEditable(false);
		textArea_10.setText(string[10]);
		scrollPane_10.setViewportView(textArea_10);
		
		JScrollPane scrollPane_11 = new JScrollPane();
		scrollPane_11.setBounds(314, 277, 110, 50);
		panel.add(scrollPane_11);
		
		JTextArea textArea_11 = new JTextArea();
		textArea_11.setEnabled(false);
		textArea_11.setEditable(false);
		textArea_11.setText(string[11]);
		scrollPane_11.setViewportView(textArea_11);
		
	}
}
