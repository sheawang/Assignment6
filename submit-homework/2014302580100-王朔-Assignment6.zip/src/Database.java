
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.mysql.*;


public class Database {
	static Connection conn;
	static Statement sql;
	public Connection getConnection()
	{
		String drivername="com.mysql.jdbc.Driver";
		String url="jdbc:mysql://127.0.0.1:3306/my_schema";
		String username="root";
		String password="123456";
		try {
			Class.forName(drivername);
			conn=DriverManager.getConnection(url,username,password);
		} catch (SQLException|ClassNotFoundException e) {
			// TODO: handle exception
			System.out.println(e.getMessage());
		}
		return conn;
	}
	public static void insert(SignUpinfo s)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema"
					,"root", "123456");
			CallableStatement st=con.prepareCall("INSERT INTO users values(?,?)");
			st.setString(1,s.getUsername());
			st.setString(2, s.getPassword());
			st.executeUpdate();
			st.close();
			con.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
	}

}
