import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.SwingConstants;

public class User extends JFrame {

	public Connection conn;
	public Statement sql;
	private JPanel contentPane;
	private JTextField textField2;
	private JTextField textField3;
	private JTextField textField4;
	private JTextField textField5;
	private JTextField textField6;
	private JTextField textField7;
	private JTextField textField8;
	private JTextField textField9;
	private JTextField textField10;
	private JTextField textField11;
	private JTextField textField12;
	private JButton button1;
	private JButton button;
	private JButton button_2;
	private JButton button_3;
	private JButton button_4;
	private JButton button_5;
	private JButton button_6;
	private JButton button_7;
	private JButton button_8;
	private JButton button_9;
	private JButton button_10;
	private JTextField textField1;
	static int num;//��¼�����ݿ��еĵڼ�������
	private JButton button_1;
	private JPanel panel;
	private JButton button_11;
	private JButton button_12;
	private JButton button_13;

//	/**
//	 * Launch the application.
//	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					User frame = new User();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public User() {
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel1 = new JPanel();
		panel1.setBounds(0, 0, 434, 262);
		contentPane.add(panel1);
		panel1.setLayout(null);
		
		textField1 = new JTextField();
		textField1.setFont(new Font("��Բ", Font.BOLD, 18));
		textField1.setText("  dog");
		textField1.setColumns(10);
		textField1.setBounds(20, 59, 80, 70);
		panel1.add(textField1);
		
		
		
		textField2 = new JTextField();
		textField2.setFont(new Font("��Բ", Font.BOLD, 18));
		textField2.setText("  cat");
		textField2.setColumns(10);
		textField2.setBounds(124, 59, 80, 70);
		panel1.add(textField2);
		
		textField3 = new JTextField();
		textField3.setHorizontalAlignment(SwingConstants.CENTER);
		textField3.setFont(new Font("��Բ", Font.BOLD, 18));
		textField3.setText("turtle");
		textField3.setColumns(10);
		textField3.setBounds(230, 59, 80, 70);
		panel1.add(textField3);
		
		textField4 = new JTextField();
		textField4.setHorizontalAlignment(SwingConstants.CENTER);
		textField4.setFont(new Font("��Բ", Font.BOLD, 18));
		textField4.setText("parrot");
		textField4.setColumns(10);
		textField4.setBounds(331, 59, 80, 70);
		panel1.add(textField4);
		
		textField5 = new JTextField();
		textField5.setHorizontalAlignment(SwingConstants.CENTER);
		textField5.setFont(new Font("��Բ", Font.BOLD, 18));
		textField5.setText("hamster");
		textField5.setColumns(10);
		textField5.setBounds(20, 181, 80, 70);
		panel1.add(textField5);
		
		textField6 = new JTextField();
		textField6.setFont(new Font("��Բ", Font.BOLD, 15));
		textField6.setText("squirrel");
		textField6.setColumns(10);
		textField6.setBounds(124, 181, 80, 70);
		panel1.add(textField6);
		
		textField7 = new JTextField();
		textField7.setFont(new Font("��Բ", Font.BOLD, 18));
		textField7.setText("rubbit");
		textField7.setHorizontalAlignment(SwingConstants.CENTER);
		textField7.setColumns(10);
		textField7.setBounds(230, 181, 80, 70);
		panel1.add(textField7);
		
		textField8 = new JTextField();
		textField8.setFont(new Font("��Բ", Font.BOLD, 18));
		textField8.setText("snake");
		textField8.setHorizontalAlignment(SwingConstants.CENTER);
		textField8.setColumns(10);
		textField8.setBounds(331, 181, 80, 70);
		panel1.add(textField8);
		
		textField9 = new JTextField();
		textField9.setFont(new Font("��Բ", Font.BOLD, 18));
		textField9.setHorizontalAlignment(SwingConstants.CENTER);
		textField9.setText("lizard");
		textField9.setColumns(10);
		textField9.setBounds(20, 295, 80, 70);
		panel1.add(textField9);
		
		textField10 = new JTextField();
		textField10.setFont(new Font("��Բ", Font.BOLD, 18));
		textField10.setText("fish");
		textField10.setHorizontalAlignment(SwingConstants.CENTER);
		textField10.setColumns(10);
		textField10.setBounds(124, 295, 80, 70);
		panel1.add(textField10);
		
		textField11 = new JTextField();
		textField11.setFont(new Font("��Բ", Font.BOLD, 18));
		textField11.setHorizontalAlignment(SwingConstants.CENTER);
		textField11.setText("myna");
		textField11.setColumns(10);
		textField11.setBounds(230, 295, 80, 70);
		panel1.add(textField11);
		
		textField12 = new JTextField();
		textField12.setFont(new Font("��Բ", Font.BOLD, 18));
		textField12.setHorizontalAlignment(SwingConstants.CENTER);
		textField12.setText("canary");
		textField12.setColumns(11);
		textField12.setBounds(331, 295, 80, 70);
		panel1.add(textField12);
		//��ʾ����
		button1 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button1.setFont(new Font("����", Font.BOLD, 10));
		button1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				num=0;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button1.setBounds(20, 139, 80, 20);
		panel1.add(button1);
		
		//��ʾ����
		button = new JButton("\u663E\u793A\u8BE6\u60C5");
		button.setFont(new Font("����", Font.BOLD, 10));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=1;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button.setBounds(124, 139, 80, 20);
		panel1.add(button);
		
		button_1 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_1.setFont(new Font("����", Font.BOLD, 10));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=2;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_1.setBounds(230, 139, 80, 20);
		panel1.add(button_1);
		
		button_2 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_2.setFont(new Font("����", Font.BOLD, 10));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=3;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_2.setBounds(331, 139, 80, 20);
		panel1.add(button_2);
		
		button_3 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_3.setFont(new Font("����", Font.BOLD, 10));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=4;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_3.setBounds(20, 261, 80, 20);
		panel1.add(button_3);
		
		button_4 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_4.setFont(new Font("����", Font.BOLD, 10));
		button_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=5;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_4.setBounds(124, 261, 80, 20);
		panel1.add(button_4);
		
		button_5 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_5.setFont(new Font("����", Font.BOLD, 10));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=6;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_5.setBounds(230, 261, 80, 20);
		panel1.add(button_5);
		
		button_6 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_6.setFont(new Font("����", Font.BOLD, 10));
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=7;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_6.setBounds(331, 261, 80, 20);
		panel1.add(button_6);
		
		button_7 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_7.setFont(new Font("����", Font.BOLD, 10));
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=8;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_7.setBounds(20, 375, 80, 20);
		panel1.add(button_7);
		
		button_8 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_8.setFont(new Font("����", Font.BOLD, 10));
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=9;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_8.setBounds(124, 374, 80, 20);
		panel1.add(button_8);
		
		button_9 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_9.setFont(new Font("����", Font.BOLD, 10));
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=10;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_9.setBounds(230, 374, 80, 20);
		panel1.add(button_9);
		
		button_10 = new JButton("\u663E\u793A\u8BE6\u60C5");
		button_10.setFont(new Font("����", Font.BOLD, 10));
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				num=11;
				dispose();
				Info info=new Info();
				info.setVisible(true);
			}
		});
		button_10.setBounds(331, 375, 80, 20);
		panel1.add(button_10);
		
		panel = new JPanel();
		panel.setBounds(20, 10, 394, 38);
		panel1.add(panel);
		panel.setLayout(null);
		//�ҵĹ��ﳵ����
		button_11 = new JButton("\u6211\u7684\u8D2D\u7269\u8F66");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
//				JOptionPane.showMessageDialog(null,"A����add,�����ó�����빺�ﳵ��"+"\nD����delete�����ӹ��ﳵ��ɾ������Ʒ��");
				myShoppingFrame myshopping=new myShoppingFrame();
				myshopping.setVisible(true);
			}
		});
		button_11.setBounds(0, 10, 120, 28);
		panel.add(button_11);
		
		//�ҵ��˻�
		button_12 = new JButton("\u6211\u7684\u8D26\u6237");
		button_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				myCountFrame mycount=new myCountFrame();
				mycount.setVisible(true);
			}
		});
		button_12.setBounds(274/2, 10, 120, 28);
		panel.add(button_12);
		
		//�˳���½
		button_13 = new JButton("\u9000\u51FA\u767B\u9646");
		button_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
				LoginFrame login=new LoginFrame();
				login.setVisible(true);
			}
		});
		button_13.setBounds(274, 10, 120, 28);
		panel.add(button_13);
	}

	public static int getNum() {
		// TODO Auto-generated method stub
		return num;
	}
}
