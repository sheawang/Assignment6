
public class SignUpinfo {

	private String name;
	private String password;
	public SignUpinfo(String name,String password){
		this.name=name;
		this.password=password;
	}
	public String getUsername() {
		// TODO Auto-generated method stub
		return name;
	}

	public String getPassword() {
		// TODO Auto-generated method stub
		return password;
	}

}
